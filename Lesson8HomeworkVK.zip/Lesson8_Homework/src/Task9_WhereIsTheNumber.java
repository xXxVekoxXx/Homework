
public class Task9_WhereIsTheNumber {

	public static void main(String[] args) {
		
		String bulamach = "-1-3asd-12sdf45---56asdf100-1---";
		String chislo = "";
		int sum=0;
		boolean isNum = false;
		// Mykite bqha slednite:
		//Raboteshtiq kod e sled komentarite
//		for (int i=0;i<bulamach.length();i++){
//			while((bulamach.charAt(i)=='-')||((bulamach.charAt(i)>=0&&bulamach.charAt(i)<=9)&&(i<bulamach.length()))){
//				if((bulamach.charAt(i)=='-')&&(chislo=="")){
//					chislo="-";
//					i++;
//					System.out.println(i+" 1");
//					isNum = true;
//				}
//				if((bulamach.charAt(i)!='-')&&(!isNum)){
//					System.out.println(i+" 2");
//					chislo=chislo+bulamach.charAt(i);
//					System.out.println(chislo);
//					i++;
//					isNum= true;
//				}
//				if((bulamach.charAt(i)=='-')&&(chislo!="")&&(!isNum)){
//					System.out.println(i+" 3");
//					System.out.println(chislo);
//					sum=sum+Integer.parseInt(chislo);
//					chislo="";
//					i++;
//				}
//				isNum= false;
//			}
//			if((chislo!="")&&(chislo!="-")){
//			System.out.println(chislo);
//			sum=sum+Integer.parseInt(chislo);
//			}
//			chislo="";
//		}
//		System.out.println("������ � : "+sum);
//		
//		
//		for(int i =0;i<bulamach.length();i++){
//			if((bulamach.charAt(i)=='-')||((bulamach.charAt(i)>=0)&&(bulamach.charAt(i)<=9))){
//				chislo=chislo+bulamach.charAt(i);
//			}
//			else{
//				if(chislo!=""){
//				System.out.println(chislo);
//				sum=sum+Integer.parseInt(chislo);
//				chislo="";
//				}
//			}
//		}
//		
		do{
			bulamach=bulamach.replace("--", "-");
		}
		while(bulamach.contains("--"));
		
	    for (int i = 0; i < bulamach.length(); i++) {
	        Character character = bulamach.charAt(i);
	        //System.out.println(character+" "+Character.isAlphabetic(character));
	        if((Character.isAlphabetic(character))&&(chislo=="-")){
	        	chislo="";
	        }
	        if (Character.isDigit(character)||character=='-') {
	        	if(character=='-'&&chislo!=""){
	        		System.out.println(chislo);
	        		sum=sum+Integer.parseInt(chislo);
	        		chislo="-";
	        	}
	        	else{
	            chislo += character;
	        	}
	        }
	        else{
	        	if(chislo!=""){
	        		System.out.println(chislo);
	        		sum=sum+Integer.parseInt(chislo);
	        		chislo="";
	        	}
	        }
	    }
	    if((chislo!="")&&(chislo!="-")){
	    	System.out.println(chislo);
	    	sum=sum+Integer.parseInt(chislo);
	    }
	    System.out.println("������ � : "+sum);

		
	}

}
