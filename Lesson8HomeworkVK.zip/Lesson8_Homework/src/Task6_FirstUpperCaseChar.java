
public class Task6_FirstUpperCaseChar {

	public static void main(String[] args) {
		
		String words = "����� ����� ������";
		boolean isFirst = true ;
		
		 for(int i =0;i<words.length();i++){
			 if(isFirst){
				 System.out.print(words.substring(i,i+1).toUpperCase());
				 isFirst = false;
			 }
			 else{
				 System.out.print(words.substring(i, i+1).toLowerCase());

			 }
			 if(words.charAt(i)==' '){
				 isFirst= true;
			 }
		 }
		

	}

}
