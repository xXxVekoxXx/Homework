
public class Task10_ASCIITransmog {

	public static void main(String[] args) {
		
		String hello = "Hello";
		System.out.println(hello);
		for(int i=0;i<hello.length();i++){
			
			int j = 5+(int)hello.charAt(i);

			System.out.print((char)j);
		}
		
		
		
		
		

	}

}
