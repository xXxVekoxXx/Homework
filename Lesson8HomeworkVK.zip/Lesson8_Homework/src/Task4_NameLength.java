
public class Task4_NameLength {

	public static void main(String[] args) {
		
		
		int sum1=0,sum2=0;
		
		String names = "Anna Dosewa Asenowa,Iwo Peew Peew";
		String name1 = names.substring(0, names.indexOf(","));
		String name2 = names.substring(names.indexOf(",")+1,names.length());
		
		for(int i=0;i<name1.length();i++){
			sum1= sum1+(int)name1.charAt(i);
		}
		for(int i=0;i<name2.length();i++){
			sum2= sum2+(int)name2.charAt(i);
		}
		if(sum1<sum2){
			System.out.println(name2);
		}
		else{
			System.out.println(name1);
		}
		
		
	}

}
