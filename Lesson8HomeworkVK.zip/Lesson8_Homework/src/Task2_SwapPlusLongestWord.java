import java.util.Scanner;

public class Task2_SwapPlusLongestWord {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a word between 10 and 20 letters long : ");
		String first = sc.nextLine();
		System.out.println("Input a word between 10 and 20 letters long : ");
		String second = sc.nextLine();
		int n = 5;
		int x = second.length();
		String firstFive = first.substring(0, 5);
		String secondLeft = second.substring(5, second.length());
		String thirdFinal = firstFive+secondLeft;
		System.out.println(thirdFinal.length()+" "+thirdFinal);


	}

}
