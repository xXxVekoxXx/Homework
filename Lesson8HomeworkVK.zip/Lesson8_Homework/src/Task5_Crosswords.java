
public class Task5_Crosswords {

	public static void main(String[] args) {
		
		String word1 = "�����";
		String word2 = "������";
		
		for(int i =0; i <word2.length();i++){
			if(word1.charAt(0)==word2.charAt(i)){
				System.out.println(word1);
			}
			else{
				System.out.println(word2.charAt(i));
			}
		}
		
		
		
		
		
		
		
		
	}

}
