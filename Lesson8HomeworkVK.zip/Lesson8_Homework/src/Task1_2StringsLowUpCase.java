
public class Task1_2StringsLowUpCase {

	public static void main(String[] args) {
		

		String first = "a,V,C,d,R";
		String second = "t,P,s,S,Q,q";
		
		System.out.println(first.toLowerCase());
		System.out.println(first.toUpperCase());
		System.out.println(second.toLowerCase());
		System.out.println(second.toUpperCase());
		
		
	}

}
