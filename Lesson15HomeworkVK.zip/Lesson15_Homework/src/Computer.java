import org.omg.Messaging.SyncScopeHelper;

public class Computer {

	int year;
	double price;
	boolean isNotebook;
	double hardDiskMemory;
	double freeMemory;
	String operationSystem;
	
	Computer(){
		isNotebook = false;
		operationSystem="Win XP";
	}
	Computer (int year, double price, double hardDistmemory, double freeMemory){
		this();
		this.year=year;
		this.price=price;
		this.hardDiskMemory = hardDistmemory;
		this.freeMemory=freeMemory;
		
	}
	
	Computer (int year, double price, double hardDistmemory,boolean isNotebook, double freeMemory, String operationSystem){
		this.year=year;
		this.price=price;
		this.hardDiskMemory=hardDistmemory;
		this.isNotebook=isNotebook;
		this.freeMemory=freeMemory;
		this.operationSystem=operationSystem;
	}
	int comparePrice(Computer c){
		if(this.price>c.price){
			return -1;
		}
		if(this.price<c.price){
			return 1;
		}
		return 0;
	}
	
	
	
	
	
	
	
	
	
	
	void changeOS(String newOS){
		operationSystem=newOS;
	}
	void useMemory(double memory){
		if(memory>freeMemory){
			System.out.println("Not enough free memory");
		}
		else{
			freeMemory=freeMemory-memory;
		}
	}
	
}
