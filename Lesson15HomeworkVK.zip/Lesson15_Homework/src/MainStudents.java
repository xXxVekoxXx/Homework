
public class MainStudents {

	public static void main(String[] args) {
		
		Student ivan = new Student("Ivan","BIT",25);
		Student pesho = new Student("Pesho","BM",19);
		Student kiro = new Student("kiro","STD",20);
		Student ivo = new Student("Ivo","M",31);
		Student spaska = new Student("Spaska","BIT",25);
		

		spaska.grade=5.75;
		spaska.upYear();
		spaska.receiveScholarship(5.50, 550);
		
		
		StudentGroup bit= new StudentGroup("BIT");
		bit.addStudent(ivan);
		bit.addStudent(kiro);
		bit.addStudent(ivo);
		bit.addStudent(pesho);
		bit.addStudent(spaska);
		bit.printStudentsinGroup();
		
		System.out.println(bit.theBestStudent());
		bit.emptyGroup();
		System.out.println(bit.theBestStudent());
		bit.addStudent(ivan);
		System.out.println(bit.theBestStudent());
		
		
		
		
	}

}
