
public class GSM {

	String model;
	boolean hasSimCard=false;
	String simMobileNumber;
	double outgoingCalls;
	String lastIncomingCall;
	String lastOutgoingCall;
	
	void insertSimCard(String number){
		if(number.length()==10 &&number.startsWith("08")){
			simMobileNumber=number;
			hasSimCard = true;
		}
		else{
			System.out.println("Invalid number");
		}
	}
	
	void removeSim(){
		hasSimCard=false;
	}
	void call(GSM receiver,double duration, GSM caller){
		if((duration>0)&&(receiver.equals(caller)==false)&&(receiver.hasSimCard==true)&&(caller.hasSimCard==true)){
			caller.outgoingCalls+=duration;
			caller.lastOutgoingCall= receiver.simMobileNumber;
			receiver.lastIncomingCall = caller.simMobileNumber;
		}
		else{
			System.out.println("No call was made- invalid values");
		}
	}
	
	double getSumForCalls(GSM name){
		Call price = new Call();
		return name.outgoingCalls*price.priceForMinute;
		
	}
	
	String infoLastoutgoingCall(GSM name){
		String lastCall="";
		if(name.lastOutgoingCall!=""){
		
		name.lastOutgoingCall = lastCall;
		return lastCall;
		}
		return "No calls ware made";

	}
	
	String infoLastIncomingCall(GSM name){
		String lastCall="";
		if(name.lastIncomingCall!=""){
		
		name.lastIncomingCall = lastCall;
		return lastCall;
		}
		return "No calls ware accepted";

	}
}
