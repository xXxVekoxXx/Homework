
public class StudentGroup {

	String groupSubject;
	Student [] students;
	int freePlaces;
	private int x;
	
	public StudentGroup() {
	students = new Student[5];
	freePlaces =5;
	}
	StudentGroup(String groupSubject){
		this();
		this.groupSubject=groupSubject;
	}
	
	void addStudent(Student s){
		if(this.groupSubject==s.subject&&this.freePlaces>0){
			this.students[5-this.freePlaces]=s;
			this.freePlaces--;
		}
	}
	
	void emptyGroup(){
		this.students= new Student[5];
		this.freePlaces=5;
	}
	
	String theBestStudent(){
		double maxGrade=0;
		String maxName="Group is Empty";
		if(this.freePlaces!=5){
			maxGrade=this.students[0].grade;
			maxName=this.students[0].name;
			for (int i = 0; i < (5-this.freePlaces); i++) {
				if(maxGrade<this.students[i].grade){
					maxGrade=this.students[i].grade;
					maxName=this.students[i].name;
				}
			}
		}
		return maxName;
		
	}
	
	void printStudentsinGroup(){
		for (int i = 0; i < (5-this.freePlaces); i++) {
			System.out.print(this.students[i].name+", "+this.students[i].grade+", "+this.students[i].subject+", "+this.students[i].yearInCollage+", "+this.students[i].money);
			System.out.println();
		}
	}
	
	
	
}
