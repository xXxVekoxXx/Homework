
public class Call {

	double priceForMinute = 0.45;
	String caller;
	String receiver;
	double duration;
}
