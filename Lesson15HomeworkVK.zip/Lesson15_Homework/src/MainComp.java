
public class MainComp {

	public static void main(String[] args) {
		
		Computer dell = new Computer();
		Computer hp = new Computer();
		Computer IBM = new Computer(2014, 1499.99, 500, true, 480, "Win 10");
		Computer asus = new Computer(2005, 999.99, 200, 180);
		dell.freeMemory=500;
		dell.hardDiskMemory=500;
		dell.isNotebook = true;
		dell.operationSystem = "Windows";
		dell.price = 1499.99;
		dell.year = 2010;
		System.out.println(dell.freeMemory+" "+dell.hardDiskMemory+" "+dell.operationSystem+" "+dell.price+" "+dell.year);
		dell.useMemory(100);
		
		hp.freeMemory=500;
		hp.hardDiskMemory = 700;
		hp.isNotebook = false;
		hp.operationSystem = "Mac";
		hp.price = 999.99;
		hp.year = 2010;
		System.out.println(hp.freeMemory+" "+hp.hardDiskMemory+" "+hp.operationSystem+" "+hp.price+" "+hp.year);
		hp.changeOS("Linux");
		
		
		System.out.println(IBM.comparePrice(dell));
		System.out.println("Godina na proizvodstvo: "+asus.year+" "+"Cena: "+asus.price+" "+"Pamet: "+asus.hardDiskMemory+" "+"Svobodna Pamet: "+asus.freeMemory+" "+"OS: "+asus.operationSystem);
		
		
		
		
		System.out.println("After methods");
		System.out.println(dell.freeMemory+" "+dell.hardDiskMemory+" "+dell.operationSystem+" "+dell.price+" "+dell.year);
		System.out.println(hp.freeMemory+" "+hp.hardDiskMemory+" "+hp.operationSystem+" "+hp.price+" "+hp.year);

	}

}
