
public class MainGSM {

	public static void main(String[] args) {
		GSM nokia = new GSM();
		GSM htc = new GSM();
		nokia.model = "Nokia";
		nokia.insertSimCard("0896585555");

		htc.model = "HTS";
		htc.insertSimCard("0887865959");


		System.out.println(nokia.hasSimCard+" "+nokia.simMobileNumber);
		System.out.println(htc.hasSimCard+" "+htc.simMobileNumber);

		nokia.call(htc, 6, nokia);
		
		System.out.println("Last number you called: "+nokia.lastOutgoingCall);
		System.out.println("Last number you answerd: "+htc.lastIncomingCall);
		System.out.println("You have talked for: "+nokia.outgoingCalls+" minutes");
		System.out.println("Your bil is: "+nokia.getSumForCalls(nokia)+"lv");
	}

}
